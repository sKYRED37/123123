hots_rosters
============
Standoff 2 team rosters from Rankoff.org World Ranking.
Ranking date: 3 November 2026
Teams: 24
Each team has its own TXT file with rank, region, points and listed players.
Source: https://rankoff.org/rankings/teams?date=2026-11-03

Note: Devilish Gang is listed with four player names on the source page.
